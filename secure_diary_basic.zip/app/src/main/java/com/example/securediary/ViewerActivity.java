package com.example.securediary;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ViewerActivity extends AppCompatActivity {
    TextView tvTitle, tvContent;
    AppDatabase db;
    long entryId;
    String password;
    byte[] salt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewer);

        tvTitle = findViewById(R.id.tvTitle);
        tvContent = findViewById(R.id.tvContent);

        entryId = getIntent().getLongExtra("entryId", -1);
        password = getIntent().getStringExtra("password");
        salt = CryptoUtils.hexToBytes(getIntent().getStringExtra("salt"));

        db = AppDatabase.getInstance(getApplicationContext());

        load();
    }

    void load() {
        AsyncTask.execute(() -> {
            DiaryEntry e = db.diaryDao().getById(entryId);
            if (e == null) return;
            runOnUiThread(() -> tvTitle.setText(e.title));
            try {
                Bitmap b = BitmapFactory.decodeByteArray(e.imageData, 0, e.imageData.length);
                byte[] hidden = StegoUtils.extractData(b);
                if (hidden == null) {
                    runOnUiThread(() -> tvContent.setText("[No hidden data found]"));
                    return;
                }
                byte[] key = CryptoUtils.deriveKeyFromPassword(password, salt);
                byte[] decrypted = CryptoUtils.decrypt(key, hidden);
                final String s = new String(decrypted, "UTF-8");
                runOnUiThread(() -> tvContent.setText(s));
            } catch (Exception ex) {
                ex.printStackTrace();
                runOnUiThread(() -> Toast.makeText(ViewerActivity.this, "Failed to load entry", Toast.LENGTH_SHORT).show());
            }
        });
    }
}
