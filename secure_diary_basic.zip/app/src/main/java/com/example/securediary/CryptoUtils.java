package com.example.securediary;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.SecureRandom;

public class CryptoUtils {
    private static final int ITER = 10000;
    private static final int KEY_SIZE = 256;

    public static byte[] deriveKeyFromPassword(String password, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, ITER, KEY_SIZE);
        SecretKeyFactory skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        byte[] key = skf.generateSecret(spec).getEncoded();
        return key;
    }

    public static byte[] encrypt(byte[] keyBytes, byte[] plain) throws Exception {
        SecureRandom rnd = new SecureRandom();
        byte[] iv = new byte[16];
        rnd.nextBytes(iv);
        IvParameterSpec ivSpec = new IvParameterSpec(iv);
        SecretKeySpec key = new SecretKeySpec(slice(keyBytes, 0, 32), "AES");
        Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
        c.init(Cipher.ENCRYPT_MODE, key, ivSpec);
        byte[] ct = c.doFinal(plain);
        byte[] out = new byte[iv.length + ct.length];
        System.arraycopy(iv, 0, out, 0, iv.length);
        System.arraycopy(ct, 0, out, iv.length, ct.length);
        return out;
    }

    public static byte[] decrypt(byte[] keyBytes, byte[] ivAndCipher) throws Exception {
        byte[] iv = slice(ivAndCipher, 0, 16);
        byte[] ct = slice(ivAndCipher, 16, ivAndCipher.length - 16);
        SecretKeySpec key = new SecretKeySpec(slice(keyBytes, 0, 32), "AES");
        Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
        c.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(iv));
        byte[] pt = c.doFinal(ct);
        return pt;
    }

    private static byte[] slice(byte[] arr, int start, int len) {
        byte[] r = new byte[len];
        System.arraycopy(arr, start, r, 0, len);
        return r;
    }

    public static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b: bytes) sb.append(String.format("%02x", b & 0xff));
        return sb.toString();
    }
    public static byte[] hexToBytes(String s) {
        if (s == null || s.length() == 0) return new byte[0];
        int l = s.length();
        byte[] out = new byte[l/2];
        for (int i=0;i<l;i+=2) {
            out[i/2] = (byte) Integer.parseInt(s.substring(i,i+2), 16);
        }
        return out;
    }
}
