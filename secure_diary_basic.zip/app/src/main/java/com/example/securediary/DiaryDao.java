package com.example.securediary;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao
public interface DiaryDao {
    @Insert
    long insert(DiaryEntry entry);

    @Query("SELECT * FROM DiaryEntry ORDER BY createdAt DESC")
    List<DiaryEntry> getAll();

    @Query("SELECT * FROM DiaryEntry WHERE id = :id")
    DiaryEntry getById(long id);
}
