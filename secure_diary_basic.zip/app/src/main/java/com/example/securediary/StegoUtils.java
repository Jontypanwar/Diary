package com.example.securediary;

import android.graphics.Bitmap;
import android.graphics.Color;
import java.nio.ByteBuffer;

public class StegoUtils {
    public static Bitmap embedData(Bitmap src, byte[] data) throws Exception {
        int len = data.length;
        byte[] lenBytes = ByteBuffer.allocate(4).putInt(len).array();
        byte[] all = new byte[4 + len];
        System.arraycopy(lenBytes, 0, all, 0, 4);
        System.arraycopy(data, 0, all, 4, len);

        Bitmap bmp = src.copy(Bitmap.Config.ARGB_8888, true);
        int w = bmp.getWidth();
        int h = bmp.getHeight();
        int capacity = w * h * 3;
        if (all.length * 8 > capacity) throw new Exception("Image too small for data");

        int bitIndex = 0;
        outer:
        for (int y=0;y<h;y++){
            for (int x=0;x<w;x++){
                int px = bmp.getPixel(x,y);
                int a = Color.alpha(px);
                int r = Color.red(px);
                int g = Color.green(px);
                int b = Color.blue(px);
                for (int i=0;i<3;i++){
                    if (bitIndex >= all.length * 8) {
                        int newPixel = Color.argb(a, r, g, b);
                        bmp.setPixel(x,y,newPixel);
                        break outer;
                    }
                    int byteIndex = bitIndex / 8;
                    int bitInByte = 7 - (bitIndex % 8);
                    int bit = (all[byteIndex] >> bitInByte) & 1;
                    if (i==0) r = (r & 0xFE) | bit;
                    else if (i==1) g = (g & 0xFE) | bit;
                    else b = (b & 0xFE) | bit;
                    bitIndex++;
                }
                int newPixel = Color.argb(a, r, g, b);
                bmp.setPixel(x,y,newPixel);
            }
        }
        return bmp;
    }

    public static byte[] extractData(Bitmap src) throws Exception {
        Bitmap bmp = src.copy(Bitmap.Config.ARGB_8888, false);
        int w = bmp.getWidth();
        int h = bmp.getHeight();
        int[] pixels = new int[w * h];
        bmp.getPixels(pixels,0,w,0,0,w,h);

        // read header (32 bits)
        byte[] header = new byte[4];
        int cursor = 0;
        outer:
        for (int iPix=0;iPix<pixels.length;iPix++){
            int p = pixels[iPix];
            int[] comps = {Color.red(p), Color.green(p), Color.blue(p)};
            for (int c=0;c<3;c++){
                int bit = comps[c] & 1;
                header[cursor/8] = (byte)((header[cursor/8] << 1) | bit);
                cursor++;
                if (cursor >= 32) break outer;
            }
        }
        int dataLen = ByteBuffer.wrap(header).getInt();
        if (dataLen <= 0) return null;
        byte[] out = new byte[dataLen];
        int globalBitIndex = 0;
        int outByteIndex = 0;
        int outBitInByte = 7;
        int skipBits = 32;
        for (int iPix=0;iPix<pixels.length;iPix++){
            int p = pixels[iPix];
            int[] comps = {Color.red(p), Color.green(p), Color.blue(p)};
            for (int c=0;c<3;c++){
                if (globalBitIndex < skipBits) { globalBitIndex++; continue; }
                if (outByteIndex >= out.length) {
                    return out;
                }
                int bit = comps[c] & 1;
                out[outByteIndex] = (byte)((out[outByteIndex] << 1) | bit);
                outBitInByte--;
                if (outBitInByte < 0){
                    outBitInByte = 7;
                    outByteIndex++;
                }
                globalBitIndex++;
            }
        }
        return out;
    }
}
