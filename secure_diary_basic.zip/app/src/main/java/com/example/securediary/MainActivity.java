package com.example.securediary;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    Button btnNew;
    DiaryAdapter adapter;
    AppDatabase db;
    String password;
    byte[] salt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);
        btnNew = findViewById(R.id.btnNew);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        password = getIntent().getStringExtra("password");
        String saltHex = getIntent().getStringExtra("salt");
        salt = CryptoUtils.hexToBytes(saltHex);

        db = AppDatabase.getInstance(getApplicationContext());

        adapter = new DiaryAdapter(item -> {
            Intent i = new Intent(MainActivity.this, ViewerActivity.class);
            i.putExtra("entryId", item.id);
            i.putExtra("password", password);
            i.putExtra("salt", CryptoUtils.bytesToHex(salt));
            startActivity(i);
        });
        recyclerView.setAdapter(adapter);

        btnNew.setOnClickListener(v -> {
            Intent i = new Intent(MainActivity.this, EditorActivity.class);
            i.putExtra("password", password);
            i.putExtra("salt", CryptoUtils.bytesToHex(salt));
            startActivity(i);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadEntries();
    }

    private void loadEntries() {
        AsyncTask.execute(() -> {
            List<DiaryEntry> list = db.diaryDao().getAll();
            runOnUiThread(() -> adapter.setItems(list));
        });
    }
}
