package com.example.securediary;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class DiaryEntry {
    @PrimaryKey(autoGenerate = true)
    public long id;
    public String title;
    public long createdAt;
    public byte[] imageData;
}
