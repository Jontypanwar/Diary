package com.example.securediary;

import android.graphics.Bitmap;

public class ImageUtils {
    public static Bitmap scaleDown(Bitmap realImage, float maxDimension) {
        if (realImage == null) return null;
        float ratio = Math.min(maxDimension / realImage.getWidth(), maxDimension / realImage.getHeight());
        if (ratio >= 1.0f) return realImage;
        int width = Math.round(realImage.getWidth() * ratio);
        int height = Math.round(realImage.getHeight() * ratio);
        return Bitmap.createScaledBitmap(realImage, width, height, true);
    }
}
