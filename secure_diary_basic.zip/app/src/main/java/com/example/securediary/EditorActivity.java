package com.example.securediary;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.ByteArrayOutputStream;
import java.util.Date;

public class EditorActivity extends AppCompatActivity {
    EditText etTitle, etContent;
    Button btnPickImage, btnSave;
    ImageView ivPreview;
    Bitmap selectedBitmap;
    AppDatabase db;
    String password;
    byte[] salt;

    private final ActivityResultLauncher<Intent> pickImageLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    Intent data = result.getData();
                    if (data != null) {
                        Uri uri = data.getData();
                        try {
                            Bitmap b = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                            selectedBitmap = ImageUtils.scaleDown(b, 1024);
                            ivPreview.setImageBitmap(selectedBitmap);
                        } catch (Exception e) { e.printStackTrace(); }
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);

        etTitle = findViewById(R.id.etTitle);
        etContent = findViewById(R.id.etContent);
        btnPickImage = findViewById(R.id.btnPickImage);
        btnSave = findViewById(R.id.btnSave);
        ivPreview = findViewById(R.id.ivPreview);

        password = getIntent().getStringExtra("password");
        salt = CryptoUtils.hexToBytes(getIntent().getStringExtra("salt"));

        db = AppDatabase.getInstance(getApplicationContext());

        btnPickImage.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 101);
                return;
            }
            Intent pick = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            pickImageLauncher.launch(pick);
        });

        btnSave.setOnClickListener(v -> {
            String title = etTitle.getText().toString();
            String content = etContent.getText().toString();
            if (TextUtils.isEmpty(title) || TextUtils.isEmpty(content) || selectedBitmap == null) {
                Toast.makeText(this, "Title, content and image required", Toast.LENGTH_SHORT).show();
                return;
            }
            AsyncTask.execute(() -> {
                try {
                    byte[] key = CryptoUtils.deriveKeyFromPassword(password, salt);
                    byte[] encrypted = CryptoUtils.encrypt(key, content.getBytes("UTF-8"));

                    Bitmap stego = StegoUtils.embedData(selectedBitmap, encrypted);
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    stego.compress(Bitmap.CompressFormat.PNG, 100, baos);
                    byte[] imageBytes = baos.toByteArray();

                    DiaryEntry entry = new DiaryEntry();
                    entry.title = title;
                    entry.createdAt = new Date().getTime();
                    entry.imageData = imageBytes;

                    long id = db.diaryDao().insert(entry);
                    runOnUiThread(() -> {
                        Toast.makeText(EditorActivity.this, "Saved", Toast.LENGTH_SHORT).show();
                        finish();
                    });
                } catch (Exception ex) {
                    ex.printStackTrace();
                    runOnUiThread(() -> Toast.makeText(EditorActivity.this, "Save failed", Toast.LENGTH_SHORT).show());
                }
            });
        });
    }
}
