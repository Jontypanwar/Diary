package com.example.securediary;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.security.SecureRandom;

public class LoginActivity extends AppCompatActivity {
    private static final String PREFS = "secure_prefs";
    private static final String KEY_SALT = "k_salt";
    private static final String KEY_PASS_VER = "k_pass_ver"; // store encrypted verifier
    EditText etPassword;
    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(v -> {
            String pass = etPassword.getText().toString();
            if (TextUtils.isEmpty(pass)) { Toast.makeText(this, "Enter password", Toast.LENGTH_SHORT).show(); return; }

            SharedPreferences sp = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            if (!sp.contains(KEY_SALT)) {
                // first time - register
                try {
                    byte[] salt = new byte[16];
                    new SecureRandom().nextBytes(salt);
                    byte[] key = CryptoUtils.deriveKeyFromPassword(pass, salt);
                    byte[] verifier = CryptoUtils.encrypt(key, "verifier:secure-diary".getBytes("UTF-8"));
                    SharedPreferences.Editor ed = sp.edit();
                    ed.putString(KEY_SALT, CryptoUtils.bytesToHex(salt));
                    ed.putString(KEY_PASS_VER, CryptoUtils.bytesToHex(verifier));
                    ed.apply();
                    startMain(pass, salt);
                } catch (Exception ex) {
                    ex.printStackTrace();
                    Toast.makeText(this, "Registration failed", Toast.LENGTH_SHORT).show();
                }
            } else {
                // verify
                try {
                    byte[] salt = CryptoUtils.hexToBytes(sp.getString(KEY_SALT, ""));
                    byte[] storedVerifier = CryptoUtils.hexToBytes(sp.getString(KEY_PASS_VER, ""));
                    byte[] key = CryptoUtils.deriveKeyFromPassword(pass, salt);
                    byte[] decrypted = CryptoUtils.decrypt(key, storedVerifier);
                    String s = new String(decrypted, "UTF-8");
                    if (s.startsWith("verifier:")) {
                        startMain(pass, salt);
                    } else {
                        Toast.makeText(this, "Wrong password", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    Toast.makeText(this, "Wrong password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void startMain(String pass, byte[] salt) {
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra("password", pass);
        i.putExtra("salt", CryptoUtils.bytesToHex(salt));
        startActivity(i);
        finish();
    }
}
